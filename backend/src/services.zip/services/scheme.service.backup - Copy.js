import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
import { filterSchemesForStorage, assertSchemeStorageSafe, STORAGE_GUARD_VERSION } from "./schemeStorageSafety.service.js";

dotenv.config();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// ======================================================
// GET ALL SCHEMES
// ======================================================

export async function getAllSchemes() {
  const { data, error } = await supabase
    .from("schemes")
    .select("*")
    .order("scheme_name");

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

// ======================================================
// GET SCHEME BY ID
// ======================================================

export async function getSchemeById(id) {
  const { data, error } = await supabase
    .from("schemes")
    .select("*")
    .eq("id", id)
    .single();

  if (error) {
    return null;
  }

  return data;
}

// ======================================================
// BLOCK 7 — DISCOVERY STORAGE SAFETY
// ======================================================
// Use these functions for candidates produced by the GoSubsidy
// discovery/verification pipeline. Manual/admin CRUD remains separate.

function mapDiscoveredCandidateToSchemePayload(candidate) {
  return {
    scheme_name: String(
      candidate.scheme_name ||
      candidate.schemeName ||
      candidate.canonicalProgramName ||
      candidate.title ||
      ""
    ).trim(),

    // ======================================================
    // CANONICAL PROGRAM IDENTITY
    // BLOCK 6 → BLOCK 7 → SUPABASE
    // ======================================================

    canonical_program_id: String(
      candidate.canonical_program_id ||
      candidate.canonicalProgramId ||
      ""
    ).trim() || null,

    canonical_program_name: String(
      candidate.canonical_program_name ||
      candidate.canonicalProgramName ||
      ""
    ).trim() || null,

    category: String(candidate.category || "").trim(),
    ministry: String(candidate.ministry || "").trim(),
    department: String(candidate.department || "").trim(),
    beneficiary: String(candidate.beneficiary || "").trim(),
    sector: String(candidate.sector || "").trim(),
    description: String(candidate.description || "").trim(),
    state_applicability: String(
      candidate.state_applicability || candidate.state || "All India"
    ).trim(),
    official_website: String(
      candidate.official_website || candidate.officialWebsite || ""
    ).trim(),
    official_apply_link: String(
      candidate.official_apply_link || candidate.applyLink || candidate.apply_link || ""
    ).trim(),
    guideline_pdf: String(candidate.guideline_pdf || candidate.guidelinePdf || "").trim(),
    status: String(candidate.status || "Draft").trim(),
    benefits: parseJsonField(candidate.benefits, []),
    eligibility: parseJsonField(candidate.eligibility, {}),
    documents: parseJsonField(candidate.documents, []),
    application: parseJsonField(candidate.application, {}),
    seo: parseJsonField(candidate.seo, {}),
  };
}

export async function importDiscoveredSchemes(rows = []) {
  if (!Array.isArray(rows) || rows.length === 0) {
    throw new Error("No discovered scheme records were provided.");
  }

  const { data: existingSchemes, error: existingError } = await supabase
    .from("schemes")
    .select("id, scheme_name, official_website, canonical_program_id");

  if (existingError) {
    throw new Error(`Unable to check existing schemes: ${existingError.message}`);
  }

  const storageResult = filterSchemesForStorage(rows, existingSchemes || []);
  const approvedRows = storageResult.candidates;

  if (approvedRows.length === 0) {
    return {
      success: true,
      storageGuardVersion: STORAGE_GUARD_VERSION,
      total: rows.length,
      imported: 0,
      approved: 0,
      rejected: storageResult.rejected.length,
      data: [],
      rejectedRows: storageResult.rejected,
    };
  }

  const existingNames = new Set(
    (existingSchemes || [])
      .map((scheme) => String(scheme.scheme_name || "").trim().toLowerCase())
      .filter(Boolean)
  );

  const namesSeenInBatch = new Set();
  const insertRows = [];
  const rejectedRows = [...storageResult.rejected];

  for (const candidate of approvedRows) {
    const payload = mapDiscoveredCandidateToSchemePayload(candidate);
    const normalizedName = payload.scheme_name.toLowerCase();

    if (!payload.scheme_name) {
      rejectedRows.push({
        ...candidate,
        rejectionStage: "BLOCK7_STORAGE_SAFETY",
        rejectionReason: "SCHEME_NAME_REQUIRED",
      });
      continue;
    }

    if (existingNames.has(normalizedName)) {
      rejectedRows.push({
        ...candidate,
        rejectionStage: "BLOCK7_STORAGE_SAFETY",
        rejectionReason: "DUPLICATE_SCHEME_NAME",
      });
      continue;
    }

    if (namesSeenInBatch.has(normalizedName)) {
      rejectedRows.push({
        ...candidate,
        rejectionStage: "BLOCK7_STORAGE_SAFETY",
        rejectionReason: "DUPLICATE_SCHEME_NAME_IN_BATCH",
      });
      continue;
    }

    namesSeenInBatch.add(normalizedName);
    insertRows.push(payload);
  }

  let inserted = [];
  if (insertRows.length > 0) {
    const { data, error } = await supabase
      .from("schemes")
      .insert(insertRows)
      .select();

    if (error) {
      throw new Error(`Discovered scheme storage failed: ${error.message}`);
    }

    inserted = data || [];
  }

  return {
    success: true,
    storageGuardVersion: STORAGE_GUARD_VERSION,
    total: rows.length,
    approved: approvedRows.length,
    imported: inserted.length,
    rejected: rejectedRows.length,
    data: inserted,
    rejectedRows,
  };
}

export async function createDiscoveredScheme(candidate) {
  const { data: existingSchemes, error: existingError } = await supabase
    .from("schemes")
    .select("id, scheme_name, official_website, canonical_program_id");

  if (existingError) {
    throw new Error(`Unable to check existing schemes: ${existingError.message}`);
  }

  const storageCheck = assertSchemeStorageSafe(
    candidate,
    existingSchemes || []
  );

  const payload = mapDiscoveredCandidateToSchemePayload(candidate);

  if (!payload.scheme_name) {
    throw new Error("BLOCK7_STORAGE_REJECTED: SCHEME_NAME_REQUIRED");
  }

  const { data, error } = await supabase
    .from("schemes")
    .insert([payload])
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }

  return {
    ...data,
    storageSafety: {
      guardVersion: STORAGE_GUARD_VERSION,
      approved: true,
      storageKey: storageCheck.storageKey,
    },
  };
}

// ======================================================
// CREATE SCHEME
// ======================================================

export async function createScheme(payload) {
  const { data, error } = await supabase
    .from("schemes")
    .insert([payload])
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

// ======================================================
// UPDATE SCHEME
// ======================================================

export async function updateScheme(id, payload) {
  const { data, error } = await supabase
    .from("schemes")
    .update(payload)
    .eq("id", id)
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

// ======================================================
// DELETE SCHEME
// ======================================================

export async function deleteScheme(id) {
  const { error } = await supabase
    .from("schemes")
    .delete()
    .eq("id", id);

  if (error) {
    throw new Error(error.message);
  }

  return {
    success: true,
  };
}

// ======================================================
// BULK IMPORT SCHEMES
// ======================================================
//
// Uses the EXISTING `schemes` Supabase table.
//
// Important:
// - Does NOT create another table.
// - Does NOT replace existing schemes.
// - Duplicate scheme names are skipped.
// ======================================================

export async function importSchemes(rows = []) {
  if (!Array.isArray(rows) || rows.length === 0) {
    throw new Error("No scheme records were provided.");
  }

  // ====================================================
  // GET EXISTING SCHEME NAMES
  // ====================================================

  const { data: existingSchemes, error: existingError } =
    await supabase
      .from("schemes")
      .select("id, scheme_name");

  if (existingError) {
    throw new Error(
      `Unable to check existing schemes: ${existingError.message}`
    );
  }

  const existingNames = new Set(
    (existingSchemes || [])
      .map((scheme) =>
        String(scheme.scheme_name || "")
          .trim()
          .toLowerCase()
      )
      .filter(Boolean)
  );

  // ====================================================
  // SEPARATE NEW / DUPLICATE
  // ====================================================

  const newRows = [];
  const duplicateRows = [];
  const invalidRows = [];

  const namesSeenInFile = new Set();

  for (let index = 0; index < rows.length; index++) {
    const row = rows[index];

    const schemeName = String(
      row.scheme_name || ""
    ).trim();

    // -----------------------------------------------
    // REQUIRED FIELD
    // -----------------------------------------------

    if (!schemeName) {
      invalidRows.push({
        row: index + 2,
        reason: "scheme_name is required",
      });

      continue;
    }

    const normalizedName =
      schemeName.toLowerCase();

    // -----------------------------------------------
    // DUPLICATE IN DATABASE
    // -----------------------------------------------

    if (existingNames.has(normalizedName)) {
      duplicateRows.push({
        row: index + 2,
        scheme_name: schemeName,
        reason: "Already exists",
      });

      continue;
    }

    // -----------------------------------------------
    // DUPLICATE INSIDE UPLOADED FILE
    // -----------------------------------------------

    if (namesSeenInFile.has(normalizedName)) {
      duplicateRows.push({
        row: index + 2,
        scheme_name: schemeName,
        reason: "Duplicate in uploaded file",
      });

      continue;
    }

    namesSeenInFile.add(normalizedName);

    // -----------------------------------------------
    // ONLY SEND FIELDS USED BY CURRENT SCHEME SYSTEM
    // -----------------------------------------------

    const payload = {
      scheme_name: schemeName,

      category:
        String(row.category || "").trim(),

      ministry:
        String(row.ministry || "").trim(),

      department:
        String(row.department || "").trim(),

      beneficiary:
        String(row.beneficiary || "").trim(),

      sector:
        String(row.sector || "").trim(),

      description:
        String(row.description || "").trim(),

      state_applicability:
        String(
          row.state_applicability ||
          row.state ||
          "All India"
        ).trim(),

      official_website:
        String(
          row.official_website || ""
        ).trim(),

      official_apply_link:
        String(
          row.official_apply_link ||
          row.apply_link ||
          ""
        ).trim(),

      guideline_pdf:
        String(
          row.guideline_pdf || ""
        ).trim(),

      status:
        String(
          row.status || "Draft"
        ).trim(),

      // ==============================================
      // JSONB FIELDS
      // ==============================================

      benefits: parseJsonField(
        row.benefits,
        []
      ),

      eligibility: parseJsonField(
        row.eligibility,
        {}
      ),

      documents: parseJsonField(
        row.documents,
        []
      ),

      application: parseJsonField(
        row.application,
        {}
      ),

      seo: parseJsonField(
        row.seo,
        {}
      ),
    };

    newRows.push(payload);
  }

  // ====================================================
  // INSERT NEW RECORDS
  // ====================================================

  let inserted = [];

  if (newRows.length > 0) {
    const { data, error } = await supabase
      .from("schemes")
      .insert(newRows)
      .select();

    if (error) {
      throw new Error(
        `Bulk scheme import failed: ${error.message}`
      );
    }

    inserted = data || [];
  }

  // ====================================================
  // RESULT
  // ====================================================

  return {
    success: true,

    total: rows.length,

    imported: inserted.length,

    duplicates: duplicateRows.length,

    invalid: invalidRows.length,

    data: inserted,

    duplicateRows,

    invalidRows,
  };
}

// ======================================================
// JSON FIELD HELPER
// ======================================================

function parseJsonField(value, fallback) {
  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return fallback;
  }

  // Already an object/array
  if (
    typeof value === "object"
  ) {
    return value;
  }

  const text = String(value).trim();

  if (!text) {
    return fallback;
  }

  try {
    return JSON.parse(text);
  } catch {
    // -----------------------------------------------
    // Allow simple comma-separated arrays
    // -----------------------------------------------

    if (Array.isArray(fallback)) {
      return text
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
    }

    // -----------------------------------------------
    // Invalid JSON object
    // -----------------------------------------------

    return fallback;
  }
}