import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  FaPlus,
  FaUpload,
  FaTrash,
  FaSyncAlt,
  FaLayerGroup,
} from "react-icons/fa";

import Layout from "../components/Layout";
import PageHeader from "../components/PageHeader";
import SearchBar from "../components/SearchBar";
import FilterBar from "../components/FilterBar";
import DataTable from "../components/DataTable";
import Pagination from "../components/Pagination";
import ConfirmModal from "../components/ConfirmModal";

import {
  fetchSchemes,
  deleteScheme,
} from "../../services/api";

export default function Schemes() {
  const navigate = useNavigate();

  // ==========================================
  // DATA
  // ==========================================

  const [schemes, setSchemes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // ==========================================
  // SEARCH & FILTERS
  // ==========================================

  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [ministry, setMinistry] = useState("");
  const [status, setStatus] = useState("");

  // ==========================================
  // PAGINATION
  // ==========================================

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // ==========================================
  // ROW SELECTION
  // ==========================================

  const [selectedRows, setSelectedRows] = useState([]);

  // ==========================================
  // DELETE MODAL
  // ==========================================

  const [showDeleteModal, setShowDeleteModal] =
    useState(false);

  const [schemeToDelete, setSchemeToDelete] =
    useState(null);

  const [deleting, setDeleting] = useState(false);

  // ==========================================
  // LOAD SCHEMES
  // ==========================================

  const loadSchemes = async () => {
    try {
      setLoading(true);
      setError("");

      const data = await fetchSchemes();

      setSchemes(
        Array.isArray(data)
          ? data
          : Array.isArray(data?.data)
          ? data.data
          : []
      );
    } catch (err) {
      console.error("Failed to load schemes:", err);

      setError(
        err.message ||
          "Unable to load schemes from the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSchemes();
  }, []);

  // ==========================================
  // DYNAMIC CATEGORY LIST
  // ==========================================

  const categories = useMemo(() => {
    return [
      ...new Set(
        schemes
          .map((scheme) => scheme.category)
          .filter(Boolean)
      ),
    ].sort();
  }, [schemes]);

  // ==========================================
  // DYNAMIC MINISTRY LIST
  // ==========================================

  const ministries = useMemo(() => {
    return [
      ...new Set(
        schemes
          .map((scheme) => scheme.ministry)
          .filter(Boolean)
      ),
    ].sort();
  }, [schemes]);

  // ==========================================
  // FILTERED DATA
  // ==========================================

  const filteredSchemes = useMemo(() => {
    const searchValue = search
      .trim()
      .toLowerCase();

    return schemes.filter((scheme) => {
      // Search across multiple useful fields

      const searchableText = [
        scheme.scheme_name,
        scheme.short_name,
        scheme.category,
        scheme.ministry,
        scheme.department,
        scheme.sector,
        scheme.beneficiary,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      const matchesSearch =
        !searchValue ||
        searchableText.includes(searchValue);

      const matchesCategory =
        !category ||
        scheme.category === category;

      const matchesMinistry =
        !ministry ||
        scheme.ministry === ministry;

      const matchesStatus =
        !status ||
        (scheme.status || "").toLowerCase() ===
          status.toLowerCase();

      return (
        matchesSearch &&
        matchesCategory &&
        matchesMinistry &&
        matchesStatus
      );
    });
  }, [
    schemes,
    search,
    category,
    ministry,
    status,
  ]);

  // ==========================================
  // RESET PAGE WHEN FILTER CHANGES
  // ==========================================

  useEffect(() => {
    setCurrentPage(1);
    setSelectedRows([]);
  }, [search, category, ministry, status]);

  // ==========================================
  // PAGINATION CALCULATION
  // ==========================================

  const totalPages = Math.max(
    1,
    Math.ceil(
      filteredSchemes.length / itemsPerPage
    )
  );

  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
    }
  }, [currentPage, totalPages]);

  const paginatedSchemes = useMemo(() => {
    const start =
      (currentPage - 1) * itemsPerPage;

    return filteredSchemes.slice(
      start,
      start + itemsPerPage
    );
  }, [
    filteredSchemes,
    currentPage,
    itemsPerPage,
  ]);

  // ==========================================
  // TABLE COLUMNS
  // ==========================================

  const columns = [
    {
      key: "scheme_name",
      label: "Scheme Name",
    },
    {
      key: "category",
      label: "Category",
    },
    {
      key: "ministry",
      label: "Ministry",
    },
    {
      key: "beneficiary",
      label: "Beneficiary",
    },
    {
      key: "status",
      label: "Status",
    },
  ];

  // ==========================================
  // SELECT ONE ROW
  // ==========================================

  const handleSelectRow = (id) => {
    setSelectedRows((previous) => {
      if (previous.includes(id)) {
        return previous.filter(
          (rowId) => rowId !== id
        );
      }

      return [...previous, id];
    });
  };

  // ==========================================
  // SELECT ALL CURRENT PAGE
  // ==========================================

  const handleSelectAll = () => {
    const currentPageIds =
      paginatedSchemes.map(
        (scheme) => scheme.id
      );

    const allCurrentSelected =
      currentPageIds.length > 0 &&
      currentPageIds.every((id) =>
        selectedRows.includes(id)
      );

    if (allCurrentSelected) {
      setSelectedRows((previous) =>
        previous.filter(
          (id) =>
            !currentPageIds.includes(id)
        )
      );

      return;
    }

    setSelectedRows((previous) => [
      ...new Set([
        ...previous,
        ...currentPageIds,
      ]),
    ]);
  };

  // ==========================================
  // VIEW
  // ==========================================

  const handleView = (scheme) => {
    navigate(`/schemes/${scheme.id}`);
  };

  // ==========================================
  // EDIT
  // ==========================================

  const handleEdit = (scheme) => {
    navigate(
      `/admin/edit-scheme/${scheme.id}`
    );
  };

  // ==========================================
  // OPEN DELETE MODAL
  // ==========================================

  const handleDelete = (scheme) => {
    setSchemeToDelete(scheme);
    setShowDeleteModal(true);
  };

  // ==========================================
  // CONFIRM DELETE
  // ==========================================

  const confirmDelete = async () => {
    if (!schemeToDelete?.id) return;

    try {
      setDeleting(true);

      await deleteScheme(
        schemeToDelete.id
      );

      setSchemes((previous) =>
        previous.filter(
          (scheme) =>
            scheme.id !==
            schemeToDelete.id
        )
      );

      setSelectedRows((previous) =>
        previous.filter(
          (id) =>
            id !== schemeToDelete.id
        )
      );

      setShowDeleteModal(false);
      setSchemeToDelete(null);
    } catch (err) {
      console.error(
        "Delete scheme error:",
        err
      );

      alert(
        err.message ||
          "Unable to delete scheme."
      );
    } finally {
      setDeleting(false);
    }
  };

  // ==========================================
  // RESET FILTERS
  // ==========================================

  const resetFilters = () => {
    setSearch("");
    setCategory("");
    setMinistry("");
    setStatus("");
    setCurrentPage(1);
  };

  // ==========================================
  // STATS
  // ==========================================

  const activeCount = useMemo(() => {
    return schemes.filter((scheme) => {
      const value = (
        scheme.status || ""
      ).toLowerCase();

      return (
        value === "active" ||
        value === "published"
      );
    }).length;
  }, [schemes]);

  const newCount = useMemo(() => {
    return schemes.filter(
      (scheme) =>
        (
          scheme.status || ""
        ).toLowerCase() === "new"
    ).length;
  }, [schemes]);

  // ==========================================
  // UI
  // ==========================================

  return (
    <Layout>

      {/* ======================================
          HEADER
      ====================================== */}

      <PageHeader
        title="Government Schemes"
        subtitle="Manage Central and State Government Schemes"
      />

      {/* ======================================
          MINI STATS
      ====================================== */}

      <div className="row g-3 mb-4">

        <div className="col-md-4">

          <div className="card border-0 shadow-sm h-100">

            <div className="card-body">

              <small className="text-muted">
                Total Schemes
              </small>

              <h3 className="fw-bold mb-0 mt-1">
                {schemes.length}
              </h3>

            </div>

          </div>

        </div>

        <div className="col-md-4">

          <div className="card border-0 shadow-sm h-100">

            <div className="card-body">

              <small className="text-muted">
                Active / Published
              </small>

              <h3 className="fw-bold text-success mb-0 mt-1">
                {activeCount}
              </h3>

            </div>

          </div>

        </div>

        <div className="col-md-4">

          <div className="card border-0 shadow-sm h-100">

            <div className="card-body">

              <small className="text-muted">
                New / Imported
              </small>

              <h3 className="fw-bold text-warning mb-0 mt-1">
                {newCount}
              </h3>

            </div>

          </div>

        </div>

      </div>

      {/* ======================================
          ERROR
      ====================================== */}

      {error && (
        <div
          className="alert alert-danger d-flex justify-content-between align-items-center"
          role="alert"
        >

          <span>{error}</span>

          <button
            type="button"
            className="btn btn-sm btn-outline-danger"
            onClick={loadSchemes}
          >
            <FaSyncAlt className="me-2" />
            Retry
          </button>

        </div>
      )}

      {/* ======================================
          SEARCH + ACTIONS
      ====================================== */}

      <div className="card border-0 shadow-sm mb-4">

        <div className="card-body">

          <div className="d-flex flex-wrap justify-content-between align-items-center gap-3">

            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search schemes..."
            />

            <div className="d-flex flex-wrap gap-2">

              <button
                type="button"
                className="btn btn-outline-secondary"
                onClick={loadSchemes}
                disabled={loading}
              >
                <FaSyncAlt className="me-2" />
                Refresh
              </button>

              <button
                type="button"
                className="btn btn-outline-success"
                onClick={() =>
                  navigate("/admin/upload")
                }
              >
                <FaUpload className="me-2" />
                Upload CSV / Excel
              </button>

              <button
                type="button"
                className="btn btn-primary"
                onClick={() =>
                  navigate(
                    "/admin/add-scheme"
                  )
                }
              >
                <FaPlus className="me-2" />
                Add Scheme
              </button>

            </div>

          </div>

        </div>

      </div>

      {/* ======================================
          FILTERS
      ====================================== */}

      <FilterBar
        category={category}
        ministry={ministry}
        status={status}
        categories={categories}
        ministries={ministries}
        onCategoryChange={
          setCategory
        }
        onMinistryChange={
          setMinistry
        }
        onStatusChange={setStatus}
        onReset={resetFilters}
      />

      {/* ======================================
          RESULTS INFORMATION
      ====================================== */}

      <div className="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">

        <div className="text-muted">

          <FaLayerGroup className="me-2" />

          Showing{" "}

          <strong>
            {paginatedSchemes.length}
          </strong>

          {" "}of{" "}

          <strong>
            {filteredSchemes.length}
          </strong>

          {" "}matching schemes

        </div>

        {selectedRows.length > 0 && (

          <div>

            <span className="badge bg-primary me-2">

              {selectedRows.length} selected

            </span>

            <button
              type="button"
              className="btn btn-sm btn-outline-danger"
              disabled
              title="Bulk delete will be added next"
            >
              <FaTrash className="me-2" />
              Bulk Delete
            </button>

          </div>

        )}

      </div>

      {/* ======================================
          DATA TABLE
      ====================================== */}

      <DataTable
        columns={columns}
        data={paginatedSchemes}
        loading={loading}
        selectedRows={selectedRows}
        onSelectRow={
          handleSelectRow
        }
        onSelectAll={
          handleSelectAll
        }
        onView={handleView}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />

      {/* ======================================
          PAGINATION
      ====================================== */}

      {!loading &&
        filteredSchemes.length > 0 && (

          <div className="mt-4">

            <Pagination
              currentPage={
                currentPage
              }
              totalPages={
                totalPages
              }
              onPageChange={
                setCurrentPage
              }
            />

          </div>

        )}

      {/* ======================================
          DELETE CONFIRMATION
      ====================================== */}

      <ConfirmModal
        show={showDeleteModal}
        title="Delete Scheme"
        message={
          schemeToDelete
            ? `Are you sure you want to delete "${schemeToDelete.scheme_name}"? This action cannot be undone.`
            : "Are you sure you want to delete this scheme?"
        }
        confirmText={
          deleting
            ? "Deleting..."
            : "Delete"
        }
        onCancel={() => {
          if (deleting) return;

          setShowDeleteModal(false);
          setSchemeToDelete(null);
        }}
        onConfirm={
          confirmDelete
        }
      />

    </Layout>
  );
}