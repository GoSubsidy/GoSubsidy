import React from "react";
import { NavLink } from "react-router-dom";
import {
  FaTachometerAlt,
  FaFileAlt,
  FaPlusCircle,
  FaUpload,
  FaFolder,
  FaUniversity,
  FaUsers,
  FaChartLine,
  FaCog,
  FaSignOutAlt,
  FaChevronLeft,
  FaChevronRight,
} from "react-icons/fa";
import { logout } from "../../services/authService";

export default function Sidebar({ collapsed = false, mobileOpen = false, onToggle }) {
  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      window.location.href = "/admin";
    }
  };

  const menuItems = [
    { title: "Dashboard", icon: <FaTachometerAlt />, path: "/admin/dashboard" },
    { title: "Schemes", icon: <FaFileAlt />, path: "/admin/schemes" },
    { title: "Add Scheme", icon: <FaPlusCircle />, path: "/admin/add-scheme" },
    { title: "Upload CSV", icon: <FaUpload />, path: "/admin/upload" },
    { title: "Categories", icon: <FaFolder />, path: "/admin/categories" },
    { title: "Ministries", icon: <FaUniversity />, path: "/admin/ministries" },
    { title: "Users", icon: <FaUsers />, path: "/admin/users" },
    { title: "Analytics", icon: <FaChartLine />, path: "/admin/analytics" },
    { title: "Settings", icon: <FaCog />, path: "/admin/settings" },
  ];

  return (
    <>
      {mobileOpen && <button className="admin-sidebar-backdrop" onClick={onToggle} aria-label="Close menu" />}

      <aside className={`admin-sidebar ${collapsed ? "is-collapsed" : ""} ${mobileOpen ? "is-mobile-open" : ""}`}>
        <div className="sidebar-top">
          <div className="admin-brand">
            <div className="admin-brand-mark">G</div>
            <div className="admin-brand-copy">
              <strong>Go<span>Subsidy</span></strong>
              <small>ADMIN CONSOLE</small>
            </div>
          </div>

          <nav className="sidebar-navigation" aria-label="Admin navigation">
            <div className="sidebar-section-label">WORKSPACE</div>

            <ul className="sidebar-menu">
              {menuItems.map((item) => (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    title={collapsed ? item.title : undefined}
                    className={({ isActive }) => `admin-nav-link ${isActive ? "active-menu" : ""}`}
                    onClick={() => window.innerWidth < 992 && onToggle?.()}
                  >
                    <span className="sidebar-icon">{item.icon}</span>
                    <span className="sidebar-label">{item.title}</span>
                    {item.title === "Analytics" && !collapsed && <span className="nav-live-dot" />}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        <div className="sidebar-bottom">
          <div className="sidebar-status">
            <span className="status-pulse" />
            <div className="sidebar-status-copy">
              <strong>System Online</strong>
              <small>Supabase connected</small>
            </div>
          </div>

          <button type="button" className="logout-btn" onClick={handleLogout}>
            <FaSignOutAlt />
            <span>Sign out</span>
          </button>

          <button
            type="button"
            className="sidebar-collapse-btn"
            onClick={onToggle}
            title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {collapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
        </div>
      </aside>
    </>
  );
}
